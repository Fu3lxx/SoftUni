package WorkingWithAbstractionExercise.traficLights;

public enum Color {
    RED,
    YELLOW,
    GREEN
}
